function [data, info] = driveDistanceFeedback
%DriveDistanceFeedback gives an empty data for irobot_create_msgs/DriveDistanceFeedback
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/DriveDistanceFeedback';
[data.remaining_travel_distance, info.remaining_travel_distance] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
info.MessageType = 'irobot_create_msgs/DriveDistanceFeedback';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,1);
info.MatPath{1} = 'remaining_travel_distance';
