function [data, info] = driveDistanceGoal
%DriveDistanceGoal gives an empty data for irobot_create_msgs/DriveDistanceGoal
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/DriveDistanceGoal';
[data.distance, info.distance] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.max_translation_speed, info.max_translation_speed] = ros.internal.ros2.messages.ros2.default_type('single',1,0, NaN, [0.300000011920928955078125]);
info.MessageType = 'irobot_create_msgs/DriveDistanceGoal';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,2);
info.MatPath{1} = 'distance';
info.MatPath{2} = 'max_translation_speed';
