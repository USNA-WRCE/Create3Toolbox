function [data, info] = dockGoal
%DockGoal gives an empty data for irobot_create_msgs/DockGoal
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/DockGoal';
info.MessageType = 'irobot_create_msgs/DockGoal';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,0);
