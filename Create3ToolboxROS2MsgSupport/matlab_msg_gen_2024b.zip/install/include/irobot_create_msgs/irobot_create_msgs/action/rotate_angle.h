// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:action\RotateAngle.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__ACTION__ROTATE_ANGLE_H_
#define IROBOT_CREATE_MSGS__ACTION__ROTATE_ANGLE_H_

#include "irobot_create_msgs/action/detail/rotate_angle__struct.h"
#include "irobot_create_msgs/action/detail/rotate_angle__functions.h"
#include "irobot_create_msgs/action/detail/rotate_angle__type_support.h"

#endif  // IROBOT_CREATE_MSGS__ACTION__ROTATE_ANGLE_H_
