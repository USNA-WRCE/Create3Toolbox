// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__ACTION__DOCK_HPP_
#define IROBOT_CREATE_MSGS__ACTION__DOCK_HPP_

#include "irobot_create_msgs/action/detail/dock__struct.hpp"
#include "irobot_create_msgs/action/detail/dock__builder.hpp"
#include "irobot_create_msgs/action/detail/dock__traits.hpp"

#endif  // IROBOT_CREATE_MSGS__ACTION__DOCK_HPP_
