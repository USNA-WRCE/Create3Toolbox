// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__LED_COLOR_HPP_
#define IROBOT_CREATE_MSGS__MSG__LED_COLOR_HPP_

#include "irobot_create_msgs/msg/detail/led_color__struct.hpp"
#include "irobot_create_msgs/msg/detail/led_color__builder.hpp"
#include "irobot_create_msgs/msg/detail/led_color__traits.hpp"

#endif  // IROBOT_CREATE_MSGS__MSG__LED_COLOR_HPP_
