// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:msg\AudioNoteVector.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__AUDIO_NOTE_VECTOR_H_
#define IROBOT_CREATE_MSGS__MSG__AUDIO_NOTE_VECTOR_H_

#include "irobot_create_msgs/msg/detail/audio_note_vector__struct.h"
#include "irobot_create_msgs/msg/detail/audio_note_vector__functions.h"
#include "irobot_create_msgs/msg/detail/audio_note_vector__type_support.h"

#endif  // IROBOT_CREATE_MSGS__MSG__AUDIO_NOTE_VECTOR_H_
