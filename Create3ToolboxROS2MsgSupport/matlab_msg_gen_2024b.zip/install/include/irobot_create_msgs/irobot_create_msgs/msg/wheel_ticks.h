// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:msg\WheelTicks.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_H_
#define IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_H_

#include "irobot_create_msgs/msg/detail/wheel_ticks__struct.h"
#include "irobot_create_msgs/msg/detail/wheel_ticks__functions.h"
#include "irobot_create_msgs/msg/detail/wheel_ticks__type_support.h"

#endif  // IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_H_
