// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__MOUSE_HPP_
#define IROBOT_CREATE_MSGS__MSG__MOUSE_HPP_

#include "irobot_create_msgs/msg/detail/mouse__struct.hpp"
#include "irobot_create_msgs/msg/detail/mouse__builder.hpp"
#include "irobot_create_msgs/msg/detail/mouse__traits.hpp"

#endif  // IROBOT_CREATE_MSGS__MSG__MOUSE_HPP_
