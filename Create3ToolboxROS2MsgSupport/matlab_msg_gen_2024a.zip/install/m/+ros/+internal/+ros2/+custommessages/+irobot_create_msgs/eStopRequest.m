function [data, info] = eStopRequest
%EStop gives an empty data for irobot_create_msgs/EStopRequest
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/EStopRequest';
[data.e_stop_on, info.e_stop_on] = ros.internal.ros2.messages.ros2.default_type('logical',1,0);
info.MessageType = 'irobot_create_msgs/EStopRequest';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,1);
info.MatPath{1} = 'e_stop_on';
