function [data, info] = driveArcGoal
%DriveArcGoal gives an empty data for irobot_create_msgs/DriveArcGoal
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/DriveArcGoal';
[data.TRANSLATE_FORWARD, info.TRANSLATE_FORWARD] = ros.internal.ros2.messages.ros2.default_type('int8',1,0, 1, [NaN]);
[data.TRANSLATE_BACKWARD, info.TRANSLATE_BACKWARD] = ros.internal.ros2.messages.ros2.default_type('int8',1,0, -1, [NaN]);
[data.translate_direction, info.translate_direction] = ros.internal.ros2.messages.ros2.default_type('int8',1,0);
[data.angle, info.angle] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.radius, info.radius] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.max_translation_speed, info.max_translation_speed] = ros.internal.ros2.messages.ros2.default_type('single',1,0, NaN, [0.300000011920928955078125]);
info.MessageType = 'irobot_create_msgs/DriveArcGoal';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,6);
info.MatPath{1} = 'TRANSLATE_FORWARD';
info.MatPath{2} = 'TRANSLATE_BACKWARD';
info.MatPath{3} = 'translate_direction';
info.MatPath{4} = 'angle';
info.MatPath{5} = 'radius';
info.MatPath{6} = 'max_translation_speed';
