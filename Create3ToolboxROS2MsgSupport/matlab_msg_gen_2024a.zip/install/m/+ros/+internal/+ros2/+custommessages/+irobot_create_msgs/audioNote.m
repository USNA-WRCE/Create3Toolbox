function [data, info] = audioNote
%AudioNote gives an empty data for irobot_create_msgs/AudioNote
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/AudioNote';
[data.frequency, info.frequency] = ros.internal.ros2.messages.ros2.default_type('uint16',1,0);
[data.max_runtime, info.max_runtime] = ros.internal.ros2.messages.builtin_interfaces.duration;
info.max_runtime.MLdataType = 'struct';
info.MessageType = 'irobot_create_msgs/AudioNote';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,4);
info.MatPath{1} = 'frequency';
info.MatPath{2} = 'max_runtime';
info.MatPath{3} = 'max_runtime.sec';
info.MatPath{4} = 'max_runtime.nanosec';
