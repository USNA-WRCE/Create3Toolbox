function [data, info] = audioNoteSequenceFeedback
%AudioNoteSequenceFeedback gives an empty data for irobot_create_msgs/AudioNoteSequenceFeedback
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/AudioNoteSequenceFeedback';
[data.iterations_played, info.iterations_played] = ros.internal.ros2.messages.ros2.default_type('int32',1,0);
[data.current_runtime, info.current_runtime] = ros.internal.ros2.messages.builtin_interfaces.duration;
info.current_runtime.MLdataType = 'struct';
info.MessageType = 'irobot_create_msgs/AudioNoteSequenceFeedback';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,4);
info.MatPath{1} = 'iterations_played';
info.MatPath{2} = 'current_runtime';
info.MatPath{3} = 'current_runtime.sec';
info.MatPath{4} = 'current_runtime.nanosec';
