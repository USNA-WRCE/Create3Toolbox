function [data, info] = dockStatus
%DockStatus gives an empty data for irobot_create_msgs/DockStatus
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'irobot_create_msgs/DockStatus';
[data.header, info.header] = ros.internal.ros2.messages.std_msgs.header;
info.header.MLdataType = 'struct';
[data.dock_visible, info.dock_visible] = ros.internal.ros2.messages.ros2.default_type('logical',1,0);
[data.is_docked, info.is_docked] = ros.internal.ros2.messages.ros2.default_type('logical',1,0);
info.MessageType = 'irobot_create_msgs/DockStatus';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,7);
info.MatPath{1} = 'header';
info.MatPath{2} = 'header.stamp';
info.MatPath{3} = 'header.stamp.sec';
info.MatPath{4} = 'header.stamp.nanosec';
info.MatPath{5} = 'header.frame_id';
info.MatPath{6} = 'dock_visible';
info.MatPath{7} = 'is_docked';
