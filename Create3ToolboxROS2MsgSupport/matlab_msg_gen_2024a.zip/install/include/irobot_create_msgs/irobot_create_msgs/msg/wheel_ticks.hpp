// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_HPP_
#define IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_HPP_

#include "irobot_create_msgs/msg/detail/wheel_ticks__struct.hpp"
#include "irobot_create_msgs/msg/detail/wheel_ticks__builder.hpp"
#include "irobot_create_msgs/msg/detail/wheel_ticks__traits.hpp"

#endif  // IROBOT_CREATE_MSGS__MSG__WHEEL_TICKS_HPP_
