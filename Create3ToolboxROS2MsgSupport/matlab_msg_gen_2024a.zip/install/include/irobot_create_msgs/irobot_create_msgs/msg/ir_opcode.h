// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:msg\IrOpcode.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__IR_OPCODE_H_
#define IROBOT_CREATE_MSGS__MSG__IR_OPCODE_H_

#include "irobot_create_msgs/msg/detail/ir_opcode__struct.h"
#include "irobot_create_msgs/msg/detail/ir_opcode__functions.h"
#include "irobot_create_msgs/msg/detail/ir_opcode__type_support.h"

#endif  // IROBOT_CREATE_MSGS__MSG__IR_OPCODE_H_
