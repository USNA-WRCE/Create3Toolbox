// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:msg\WheelStatus.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__WHEEL_STATUS_H_
#define IROBOT_CREATE_MSGS__MSG__WHEEL_STATUS_H_

#include "irobot_create_msgs/msg/detail/wheel_status__struct.h"
#include "irobot_create_msgs/msg/detail/wheel_status__functions.h"
#include "irobot_create_msgs/msg/detail/wheel_status__type_support.h"

#endif  // IROBOT_CREATE_MSGS__MSG__WHEEL_STATUS_H_
