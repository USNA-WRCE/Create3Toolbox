// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__SLIP_STATUS_HPP_
#define IROBOT_CREATE_MSGS__MSG__SLIP_STATUS_HPP_

#include "irobot_create_msgs/msg/detail/slip_status__struct.hpp"
#include "irobot_create_msgs/msg/detail/slip_status__builder.hpp"
#include "irobot_create_msgs/msg/detail/slip_status__traits.hpp"

#endif  // IROBOT_CREATE_MSGS__MSG__SLIP_STATUS_HPP_
