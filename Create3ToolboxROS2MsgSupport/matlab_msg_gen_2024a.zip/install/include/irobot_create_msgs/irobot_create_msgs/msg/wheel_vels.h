// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:msg\WheelVels.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__MSG__WHEEL_VELS_H_
#define IROBOT_CREATE_MSGS__MSG__WHEEL_VELS_H_

#include "irobot_create_msgs/msg/detail/wheel_vels__struct.h"
#include "irobot_create_msgs/msg/detail/wheel_vels__functions.h"
#include "irobot_create_msgs/msg/detail/wheel_vels__type_support.h"

#endif  // IROBOT_CREATE_MSGS__MSG__WHEEL_VELS_H_
