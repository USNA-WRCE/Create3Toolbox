// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:srv\EStop.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__SRV__E_STOP_H_
#define IROBOT_CREATE_MSGS__SRV__E_STOP_H_

#include "irobot_create_msgs/srv/detail/e_stop__struct.h"
#include "irobot_create_msgs/srv/detail/e_stop__functions.h"
#include "irobot_create_msgs/srv/detail/e_stop__type_support.h"

#endif  // IROBOT_CREATE_MSGS__SRV__E_STOP_H_
