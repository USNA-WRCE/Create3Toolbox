// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:srv\ResetPose.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__SRV__RESET_POSE_H_
#define IROBOT_CREATE_MSGS__SRV__RESET_POSE_H_

#include "irobot_create_msgs/srv/detail/reset_pose__struct.h"
#include "irobot_create_msgs/srv/detail/reset_pose__functions.h"
#include "irobot_create_msgs/srv/detail/reset_pose__type_support.h"

#endif  // IROBOT_CREATE_MSGS__SRV__RESET_POSE_H_
