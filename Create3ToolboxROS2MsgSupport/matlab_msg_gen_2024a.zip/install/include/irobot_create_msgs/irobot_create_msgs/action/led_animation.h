// generated from rosidl_generator_c/resource/idl.h.em
// with input from irobot_create_msgs:action\LedAnimation.idl
// generated code does not contain a copyright notice

#ifndef IROBOT_CREATE_MSGS__ACTION__LED_ANIMATION_H_
#define IROBOT_CREATE_MSGS__ACTION__LED_ANIMATION_H_

#include "irobot_create_msgs/action/detail/led_animation__struct.h"
#include "irobot_create_msgs/action/detail/led_animation__functions.h"
#include "irobot_create_msgs/action/detail/led_animation__type_support.h"

#endif  // IROBOT_CREATE_MSGS__ACTION__LED_ANIMATION_H_
